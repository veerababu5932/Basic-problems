#include<stdio.h>
int main()
{
    int r;
    scanf("%d",&r);
    printf("%.2f",3.14*r*r*1.0);
}