#include<stdio.h>
int main()
{
    char arr[100];
    scanf("%[^
]s",arr);
    printf("%s",arr);
}