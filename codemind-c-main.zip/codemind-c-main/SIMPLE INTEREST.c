#include<stdio.h>
int main()
{
    int r,t,p;
    scanf("%d%d%d",&p,&t,&r);
    printf("%d",(p*t*r)/100);
}