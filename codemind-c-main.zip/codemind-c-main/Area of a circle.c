#include<stdio.h>
#include<math.h>
int main()
{
    int r=r*1.0;
    float area;
    scanf("%d",&r);
    area=3.14*pow(r,2);
    printf("%.2f",area);
}