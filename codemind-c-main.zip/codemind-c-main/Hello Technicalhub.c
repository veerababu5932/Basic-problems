#include<stdio.h>
int main()
{
    char arr[10000];
    scanf("%[^
]s",arr);
    printf("Hello Technicalhub
");
    printf("%s",arr);
}