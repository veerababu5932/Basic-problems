#include<stdio.h>
int main()
{
    int number;
    scanf("%d",&number);
    if(number%2)
    {
        printf("Odd");
    }
    else
    {
        printf("Even");
    }
}