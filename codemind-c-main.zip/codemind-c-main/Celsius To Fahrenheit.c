#include<stdio.h>
int main()
{
    int c;
    float f;
    scanf("%d",&c);
    f=(1.8*c)+32;
    printf("%.2f",f);
}