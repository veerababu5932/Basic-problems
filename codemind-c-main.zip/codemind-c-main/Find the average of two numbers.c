#include<stdio.h>
int main()
{
    int a,b;
    float sum=0;
    scanf("%d%d",&a,&b);
    sum=a*1.0+b*1.0;
    printf("%.4f",sum/2);
}